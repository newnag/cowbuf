
<div class="contact">
    <div class="head-contact">
        <h1>ติดต่อเรา</h1>
    </div>

    <div class="text-contact">
        <h2>เยอร์บีร่าซาร์อุปนายิกาเอสเปรสโซโต๊ะจีน โอเปร่าซาดิสต์เรตคีตปฏิภาณ ตนเอง เบอร์รีฟาสต์ฟู้ด</h2>
    </div>

    <div class="contact-button">
        <a href=""><img src="/img/button/Group 107.png" alt=""></a>
        <a href=""><img src="/img/button/Group 106.png" alt=""></a>
        <a href=""><img src="/img/button/Group 105.png" alt=""></a>
    </div>

    <div class="address">
        <p>500 Terry Francois Street, San Francsico, CA 94158</p>
        <p>info@mysite.com Tel:123-456-7890 Line ID: Line1234, Facebook: 123456123</p>
    </div>

    <div class="map">
        <img src="/img/map.JPG" alt="">
    </div>
</div>