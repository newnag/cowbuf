<link rel="stylesheet" href="css/style.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/page-article.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/detail-product.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/member.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/store.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/mycart.min.css?v=<?=date('his'); ?>">
<link rel="stylesheet" href="css/slide.css?v=<?=date('his'); ?>">
<link href="fontawesome/css/all.css" rel="stylesheet">
<link rel="stylesheet" href="/OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css">
<link href="https://fonts.googleapis.com/css?family=Sarabun:300,300i,400,400i,700,700i&display=swap&subset=thai" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/slick/slick.css"/>
<link rel="stylesheet" type="text/css" href="/slick/slick-theme.css"/>
