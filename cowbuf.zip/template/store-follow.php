<div class="store-follow">
    <div class="shop-box">
        <div class="shop-grid">
            <div class="shop-head">
                <span>ชื่อร้าน</span>
                <span>คะแนน</span>
                <span>จังหวัด</span>
                <span>สินค้าทั้งหมด</span>
                <span>เบอร์โทร</span>
            </div>

            <div class="shop-detail">
                <span>ร้านนำโชค มีชัย มหารวยไชโยโห่หิ้ว</span>
                <span>10K</span>
                <span>ขอนแก่น</span>
                <span>1K</span>
                <span>084-134-1542</span>
            </div>
        </div>

        <div class="button-shop">
            <div class="view-shop"><button>ดูร้านค้า</button></div>
            <div class="delete"><button>ลบ</button></div>
        </div>
    </div>

    <div class="shop-box">
        <div class="shop-grid">
            <div class="shop-head">
                <span>ชื่อร้าน</span>
                <span>คะแนน</span>
                <span>จังหวัด</span>
                <span>สินค้าทั้งหมด</span>
                <span>เบอร์โทร</span>
            </div>

            <div class="shop-detail">
                <span>ร้านนำโชค มีชัย มหารวยไชโยโห่หิ้ว</span>
                <span>10K</span>
                <span>ขอนแก่น</span>
                <span>1K</span>
                <span>084-134-1542</span>
            </div>
        </div>

        <div class="button-shop">
            <div class="view-shop"><button>ดูร้านค้า</button></div>
            <div class="delete"><button>ลบ</button></div>
        </div>
    </div>

    <div class="shop-box">
        <div class="shop-grid">
            <div class="shop-head">
                <span>ชื่อร้าน</span>
                <span>คะแนน</span>
                <span>จังหวัด</span>
                <span>สินค้าทั้งหมด</span>
                <span>เบอร์โทร</span>
            </div>

            <div class="shop-detail">
                <span>ร้านนำโชค มีชัย มหารวยไชโยโห่หิ้ว</span>
                <span>10K</span>
                <span>ขอนแก่น</span>
                <span>1K</span>
                <span>084-134-1542</span>
            </div>
        </div>

        <div class="button-shop">
            <div class="view-shop"><button>ดูร้านค้า</button></div>
            <div class="delete"><button>ลบ</button></div>
        </div>
    </div>
</div>