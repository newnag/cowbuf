<div class="paid-history">
    <div class="history">
        <div class="head">
            <span>ชื่อลูกค้า</span>
            <span>เติม/ถอน</span>
            <span>จำนวนเงิน/เครดิต</span>
            <span>ธนาคาร</span>
            <span>เลขบัญชี</span>
            <span>วันที่ดำเนินการ</span>
        </div>

        <div class="row">
            <span>User 01010</span>
            <span>เติม</span>
            <span>10K</span>
            <span>SCB</span>
            <span>123-456-7890</span>
            <span>21/13/2035</span>
        </div>

        <div class="row">
            <span>User 02020</span>
            <span>ถอน</span>
            <span>10K</span>
            <span>TMB</span>
            <span>123-456-7890</span>
            <span>21/13/2035</span>
        </div>
    </div>
</div>