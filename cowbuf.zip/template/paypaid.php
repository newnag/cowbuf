<div class="paypaid">
    <div class="head-text">
        <div class="text">
            <h1>การเติมเงิน</h1>
        </div>
    </div>

    <div class="menu-mycart">
        <div class="leaf-menu">
            <div class="button-menu"><button id="paypaid" class="active">เติมเงิน</button></div>
            <div class="button-menu"><button id="withdraw">ถอนเงิน</button></div>
            <div class="button-menu"><button id="history-paid">ประวัติการเติมเงิน</button></div>
        </div>
    </div>

    <div class="page-paypaid">
    <?php include('template/paid-page.php') ?>
    </div>
</div>