<div class="mycart-page">
    <?php for($i=0;$i<=2;$i++): ?>
    <div class="mydetail">
        <div class="box">
            <div class="left">
                <figure><img src="/img/ID4fa1e2ab_024a_42ef_bede_658a_l.png" alt=""></figure>
            </div>

            <div class="right">
                <h3>ฮิปฮอปคาแรคเตอร์เวิร์กวีนเพทนาการ จึ๊กรีสอร์ตเคลื่อนย้าย แยมโรลเจไดแอลมอนด์ แม็กกาซีนลอจิสติกส์คอมเพล็กซ์ เที่ยงคืนซูชิ มาร์ชอีสเตอร์ทัวร์นาเมนท์ โมเต็ลพรีเซ็นเตอร์แพกเกจโนติส ดิสเครดิตไลฟ์ สแตนดาร์ด รีสอร์ทบึมวีเจแชมพู</h3>

                <div class="price-button">
                    <div class="price"><span>ราคา 9,999,999฿</span></div>
                    <div class="button">
                        <button>ดูร้านค้า</button>
                        <button>ลบ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endfor; ?>
</div>