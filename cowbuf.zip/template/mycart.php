<div class="mycart">
    <div class="head-text">
        <div class="text">
            <h1>การซื้อของฉัน</h1>
        </div>
    </div>

    <div class="menu-mycart">
        <div class="leaf-menu">
            <div class="button-menu"><button id="my-bid">สินค้ากำลังประมูล</button></div>
            <div class="button-menu"><button id="my-cart" class="active">รายการซื้อของฉัน</button></div>
            <div class="button-menu"><button id="my-fav">สินค้ารายการโปรด</button></div>
        </div>
    </div>

    <div class="page-mycart">
        <?php include('template/page-mycart.php') ?>
    </div>
</div>