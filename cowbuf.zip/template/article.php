<div class="article">
    <div class="head-text">
        <div class="text">
            <h1>บทความ</h1>
        </div>
    </div>

    <div class="grid-box">
        <?php for($i=0;$i<=14;$i++): ?>
            <a href="article-page">
                <div class="box">
                    <figure><img src="img/work.jpg" alt=""></figure>

                    <h2>บทความดีๆ มีอยู่มากมาย บทความดีๆ มีอยู่มากมาย บทความดีๆ มีอยู่มากมาย</h2>

                    <div class="date">
                        <i class="fas fa-calendar-alt"></i>
                        <span>25-12-2610</span>
                    </div>
                </div>
            </a>
        <?php endfor; ?>
    </div>
</div>